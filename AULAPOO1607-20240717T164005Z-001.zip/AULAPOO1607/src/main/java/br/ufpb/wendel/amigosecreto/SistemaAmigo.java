package br.ufpb.wendel.amigosecreto;
import java.util.ArrayList;
import java.util.List;
public class SistemaAmigo  {
    private List<Mensagem> mensagens = new ArrayList<>();
    private List<Amigo> amigos = new ArrayList<>();

    public List<Mensagem> pesquisaMensagensAnonimas(){
        List<Mensagem> mensagensAnonimas = new ArrayList<>();
        for(Mensagem a: mensagens){
            if(a.ehAnonima() == true){
                mensagensAnonimas.add(a);
            }
        }
        return mensagensAnonimas;
    }
    public void configuraAmigoSecretoDe(String emailDaPessoa, String emailAmigoSorteado) throws AmigoInexistenteException{

    }




}

